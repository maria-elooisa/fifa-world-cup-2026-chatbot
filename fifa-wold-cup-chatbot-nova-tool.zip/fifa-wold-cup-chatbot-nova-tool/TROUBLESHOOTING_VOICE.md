# 🎤 Guia de Troubleshooting - Recursos de Voz

## Status da Instalação

Execute o script de teste para verificar:
```bash
python scripts/test_voice.py
```

## Problemas Comuns e Soluções

### 1. "Erro ao gerar áudio" no TTS

**Causas possíveis:**
- Sem conexão com internet
- Problemas de certificado SSL
- Texto vazio ou inválido

**Soluções:**
```bash
# Verificar conexão
ping google.com

# Atualizar certificados (macOS)
/Applications/Python\ 3.12/Install\ Certificates.command

# OU instalar certifi
pip install --upgrade certifi
```

### 2. "Não foi possível transcrever o áudio"

**Causas possíveis:**
- Áudio muito curto ou vazio
- Ruído de fundo
- Problemas com microfone
- Idioma incorreto

**Soluções:**
- Fale mais claramente e devagar
- Reduza ruído de fundo
- Verifique permissões do microfone no navegador
- Grave áudio de pelo menos 2-3 segundos
- Verifique se o idioma selecionado está correto

### 3. FFmpeg não encontrado (aviso do pydub)

**Isso é NORMAL!** O aviso pode ser ignorado. Mas se quiser instalar:

```bash
# macOS
brew install ffmpeg

# Linux (Ubuntu/Debian)
sudo apt-get install ffmpeg

# Windows
# Baixar de: https://ffmpeg.org/download.html
```

### 4. Problema de SSL Certificate

Se aparecer erro de certificado SSL:

```bash
# macOS - Instalar certificados SSL
/Applications/Python\ 3.12/Install\ Certificates.command

# OU usar pip
pip install --upgrade certifi
```

### 5. Microfone não funciona no navegador

**Chrome/Edge:**
- Vá em Configurações → Privacidade e segurança → Configurações do site → Microfone
- Adicione seu localhost à lista de permissões

**Safari:**
- Safari → Preferências → Sites → Microfone
- Permitir para localhost

**Firefox:**
- Configurações → Privacidade e segurança → Permissões → Microfone
- Permitir para localhost

## Logs de Debug

Para ver logs detalhados, verifique o terminal onde o Streamlit está rodando. Os logs mostrarão:
- ✅ Sucesso nas operações
- ❌ Erros detalhados
- 📝 Informações sobre transcrição e TTS

## Teste Manual Rápido

### Testar TTS diretamente no Python:

```python
from gtts import gTTS
import io

tts = gTTS(text="Teste de áudio", lang="pt")
buffer = io.BytesIO()
tts.write_to_fp(buffer)
print(f"Gerou {len(buffer.getvalue())} bytes")
```

Se isso funcionar, o problema está na integração com Streamlit.

### Testar Speech Recognition:

```python
import speech_recognition as sr

recognizer = sr.Recognizer()
# Grave um áudio e salve como teste.wav
with sr.AudioFile("teste.wav") as source:
    audio = recognizer.record(source)
    text = recognizer.recognize_google(audio, language="pt-BR")
    print(f"Transcrito: {text}")
```

## Requisitos Mínimos

- ✅ Python 3.8+
- ✅ Conexão com internet (para APIs do Google)
- ✅ Navegador moderno (Chrome, Edge, Safari, Firefox)
- ✅ Permissão de microfone no navegador
- ⚠️ FFmpeg (opcional, mas recomendado)

## Suporte

Se o problema persistir:
1. Verifique os logs no terminal
2. Execute o script de teste: `python scripts/test_voice.py`
3. Verifique se há conexão com internet
4. Tente com um navegador diferente
5. Reinicie o Streamlit
