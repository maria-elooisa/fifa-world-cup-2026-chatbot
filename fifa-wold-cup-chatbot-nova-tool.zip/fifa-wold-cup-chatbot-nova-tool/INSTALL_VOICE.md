# Instalação dos Recursos de Voz

Este guia explica como instalar e configurar os recursos de acessibilidade de voz (Speech-to-Text e Text-to-Speech).

## Dependências Necessárias

As seguintes bibliotecas open-source são necessárias:

1. **SpeechRecognition** - Para reconhecimento de voz (Speech-to-Text)
2. **gTTS** (Google Text-to-Speech) - Para síntese de voz (Text-to-Speech)
3. **audio-recorder-streamlit** - Para captura de áudio no Streamlit
4. **pydub** - Para processamento de áudio (opcional, mas recomendado)

## Instalação

### 1. Ativar o ambiente virtual

```bash
source .venv/bin/activate
```

### 2. Instalar as dependências

```bash
pip install SpeechRecognition gTTS pydub audio-recorder-streamlit
```

OU instalar todas as dependências do requirements.txt:

```bash
pip install -r requirements.txt
```

### 3. Dependências do Sistema (MacOS)

Para o reconhecimento de voz funcionar melhor, instale o FFmpeg:

```bash
brew install ffmpeg
```

### 4. Reiniciar o Streamlit

Após instalar as dependências, reinicie o servidor Streamlit:

```bash
streamlit run app.py
```

## Como Usar

### Reconhecimento de Voz (Speech-to-Text)

1. Clique no ícone do **microfone** 🎤 acima do campo de chat
2. Permita o acesso ao microfone quando solicitado pelo navegador
3. Fale sua pergunta claramente
4. Clique novamente para parar a gravação
5. O texto será transcrito automaticamente e a pergunta será enviada

### Síntese de Voz (Text-to-Speech)

1. Após receber uma resposta do bot, role até a seção "Ouvir resposta"
2. Clique no botão **🔊 Msg X** correspondente à mensagem que deseja ouvir
3. O áudio será gerado e reproduzido automaticamente no idioma selecionado

## Idiomas Suportados

Ambos os recursos (Speech-to-Text e Text-to-Speech) suportam os seguintes idiomas:

- 🇧🇷 Português (pt-BR)
- 🇺🇸 English (en-US)
- 🇪🇸 Español (es-ES)
- 🇫🇷 Français (fr-FR)
- 🇩🇪 Deutsch (de-DE)
- 🇮🇹 Italiano (it-IT)
- 🇯🇵 日本語 (ja-JP)
- 🇨🇳 中文 (zh-CN)
- 🇸🇦 العربية (ar-SA)

## Solução de Problemas

### Erro: "Module not found"

Certifique-se de que instalou todas as dependências:
```bash
pip install -r requirements.txt
```

### Microfone não funciona

- Verifique se seu navegador tem permissão para acessar o microfone
- Em navegadores como Chrome/Edge, o site precisa estar em HTTPS ou localhost
- Teste em um navegador diferente (Chrome funciona melhor)

### Áudio não é reproduzido

- Verifique se o FFmpeg está instalado
- Verifique se o navegador suporta reprodução de áudio MP3
- Tente recarregar a página

### Transcrição imprecisa

- Fale mais devagar e claramente
- Reduza o ruído de fundo
- Certifique-se de que o idioma selecionado corresponde ao idioma falado

## Notas Técnicas

- **SpeechRecognition** usa o Google Speech Recognition API (gratuito, sem necessidade de chave API)
- **gTTS** usa o Google Text-to-Speech (gratuito, sem necessidade de chave API)
- **audio-recorder-streamlit** usa a MediaRecorder API do navegador para captura de áudio
- Os arquivos de áudio são processados em memória e não são salvos no disco

## Limitações

- O reconhecimento de voz requer conexão com a internet
- A síntese de voz também requer conexão com a internet
- O tamanho máximo do áudio para transcrição é limitado pela API do Google
- A qualidade da transcrição depende da qualidade do microfone e do ambiente
